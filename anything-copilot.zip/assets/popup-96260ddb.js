import{c as p,G as a}from"./Popup-fb480b48.js";p(a).mount("#app");
