(() => {
  // src/utils/ext.ts
  async function tabUpdated({ tabId, status, timeout }) {
    return new Promise((r) => {
      const handleUpdate = (id, info) => {
        console.log(id, info);
        if (id === tabId && info.status === status) {
          chrome.tabs.onUpdated.removeListener(handleUpdate);
          r();
        }
      };
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(handleUpdate);
        r();
      }, timeout || 30 * 1e3);
      chrome.tabs.onUpdated.addListener(handleUpdate);
    });
  }

  // src/bg/index.ts
  async function openPipBackground(url) {
    const tab = await chrome.tabs.create({
      url
    });
    await tabUpdated({ tabId: tab.id, status: "complete" });
    chrome.tabs.sendMessage(tab.id, {
      type: "pip",
      options: {
        url,
        mode: "write-html"
      }
    });
  }
  async function getContentCss(id, url) {
    const res = await fetch(url);
    const text = await res.text();
    chrome.tabs.sendMessage(id, {
      type: "content-css",
      payload: {
        url,
        value: text
      }
    });
  }
  async function pipLaunch(url) {
    const tab = await chrome.tabs.create({ url });
    await tabUpdated({ tabId: tab.id, status: "complete" });
    chrome.tabs.sendMessage(tab.id, {
      type: "pip-launch",
      url
    });
  }
  function handleMessage(message, sender) {
    console.log("bg message: ", message, sender);
    switch (message?.type) {
      case "bg-open-pip":
        openPipBackground(message.url);
        break;
      case "get-content-css":
        getContentCss(sender.tab?.id || 0, message.url);
        break;
      case "bg-pip-launch":
        pipLaunch(message.url);
        break;
    }
  }
  chrome.runtime.onMessage.addListener(handleMessage);
})();
