import type { PipOptions } from "@/types/pip";
import { querySome } from "@/utils/selector";

export const pipEventName = "anything-copilot-pip";

export async function pip(options: PipOptions) {
  let { mode, selector, url, isCopyStyle } = options;
  url = url || location.href;
  let element: Element | null = null;
  if (selector) {
    mode = "move-element";
    element = querySome(selector);
  }

  const pipWindow = await window.documentPictureInPicture.requestWindow({
    width: 350,
    height: 800,
  });

  if (isCopyStyle) {
    copyStyleSheets(pipWindow, document);
  }

  // navGuard(pipWindow);

  if (mode === "iframe") {
    const iframe = document.createElement("iframe");
    iframe.src = url;
    iframe.id = "";
    iframe.setAttribute("style", "width: 100%; height: 100%; border: none;");
    pipWindow.document.body.append(iframe);
    return;
  }

  if (mode === "move-element") {
    if (element) {
      pipWindow.document.body.append(element);
      return;
    } else {
      throw Error("selector not found");
    }
  }

  if (mode === "write-html") {
    const res = await fetch(url);
    const html = await res.text();
    writeHtml(pipWindow, html);
    return;
  }
}

function copyStyleSheets(pipWindow: Window, document: Document) {
  [...document.styleSheets].forEach((styleSheet) => {
    try {
      const cssRules = [...styleSheet.cssRules]
        .map((rule) => rule.cssText)
        .join("");
      const style = document.createElement("style");

      style.textContent = cssRules;
      pipWindow.document.head.appendChild(style);
    } catch (e) {
      const link = document.createElement("link");

      link.rel = "stylesheet";
      link.type = styleSheet.type;
      link.media = styleSheet.media as any;
      link.href = styleSheet.href as string;
      pipWindow.document.head.appendChild(link);
    }
  });
}

function getDomNonce() {
  for (let script of document.querySelectorAll("script")) {
    if (script.nonce) {
      return script.nonce;
    }
  }
  return "";
}

function getHtmlNonce(html: string) {
  const match = html.match(/nonce='(.+?)'|nonce=".+?"/);
  if (match) {
    return match[1];
  }
  return "";
}

function writeHtml(pipWindow: Window, html: string) {
  const nonce = getDomNonce();
  let escaped = html.replace(/nonce="(.+?)"/g, `nonce="${nonce}"`);

  if (window.trustedTypes) {
    const escapeHTMLPolicy = window.trustedTypes.createPolicy(
      "myEscapePolicy",
      {
        createHTML: (string: string) => string,
      }
    );
    escaped = escapeHTMLPolicy.createHTML(escaped);
  }

  pipWindow.document.open();
  pipWindow.document.write(escaped);
  pipWindow.document.close();

  const base = document.createElement("base");
  base.target = "_blank";
  pipWindow.document.head.append(base);

  disablePrerender(pipWindow);
}

function disablePrerender(pipWindow: Window) {
  const rules = pipWindow.document.querySelectorAll(
    'script[type="speculationrules"]'
  );
  if (rules) {
    rules.forEach((s) => s.remove());
  }
}

// function navGuard(pipWindow: Window) {
//   pipWindow.addEventListener("beforeunload", (e) => {
//     e.preventDefault();
//     e.returnValue = true;
//     console.log(e);
//   });
// }
