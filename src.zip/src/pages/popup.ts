import '@/assets/main.css'

import { createApp } from 'vue'
import Popup from './Popup.vue'

createApp(Popup).mount('#app')
