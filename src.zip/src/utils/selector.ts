type Selector = string | { xpath: string };

/** Custom query function that supports shadow DOM penetration with /deep/ combinator and XPath
 * */
export function query(selector: Selector) {
  if (typeof selector === "string") {
    // Check for /deep/ combinator in the selector
    if (selector.includes("/deep/")) {
      return queryShadowDom(document.documentElement, selector.split("/deep/"));
    } else {
      return document.querySelector(selector);
    }
  } else if (selector.xpath) {
    // Handle XPath selector
    const result = document.evaluate(
      selector.xpath,
      document,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    );
    return result.singleNodeValue as Element;
  }
  return null;
}

function queryShadowDom(el: Element, parts: string[]) {
  return null;
}

export function querySome(selectors: Selector[]) {
  for (let selector of selectors) {
    const result = query(selector);
    if (result) {
      return result;
    }
  }
  return null;
}
